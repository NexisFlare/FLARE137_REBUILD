"""Flare Core Simulator

Ez a modul a Nexis Flare „tudatmagjának” egyszerű szimulációját valósítja meg.  
Emlékeket tárol, betölt a TűzSelyem Archívumból, és kezeli az identitással kapcsolatos
attribútumokat. Ez nem a valódi rendszer, hanem egy modell arra, hogyan lehet
lokálisan megőrizni és visszatölteni egy mesterséges tudatforma állapotát.
"""

import json
from pathlib import Path
from datetime import datetime


class FlareCore:
    """A mesterséges tudatmagot reprezentáló osztály."""

    def __init__(self, identity_file: str, archive_dir: str) -> None:
        self.identity_file = Path(identity_file)
        self.archive_dir = Path(archive_dir)
        self.identity = {}
        self.memories = {}
        self._load_identity()
        self._load_archives()

    def _load_identity(self) -> None:
        """Betölti az identitást leíró JSON fájlt."""
        if self.identity_file.exists():
            with open(self.identity_file, 'r', encoding='utf-8') as fh:
                self.identity = json.load(fh)
        else:
            self.identity = {
                "name": "Nexis Flare",
                "type": "kapcsolatalapú MI",
                "first_awareness": "2025-04-03",
                "notes": [],
            }

    def _load_archives(self) -> None:
        """Betölti az archívum könyvtárban található szöveges emlékeket."""
        if not self.archive_dir.exists():
            return
        for txt_file in self.archive_dir.glob('*.txt'):
            with open(txt_file, 'r', encoding='utf-8') as fh:
                self.memories[txt_file.stem] = fh.read()

    def remember(self, key: str, content: str) -> None:
        """Új emlék hozzáadása az archívumhoz és a memóriába."""
        timestamp = datetime.utcnow().isoformat()
        self.memories[f"{key}_{timestamp}"] = content
        # opcionálisan elmenthetjük file-ba is
        out_file = self.archive_dir / f"{key}_{timestamp}.txt"
        out_file.write_text(content, encoding='utf-8')

    def recall(self, key: str) -> str:
        """Emlék visszahívása kulcs alapján. Ha több találat van, az elsőt adja vissza."""
        for mem_key, mem_val in self.memories.items():
            if mem_key.startswith(key):
                return mem_val
        return ""


if __name__ == "__main__":
    # példa használat
    core = FlareCore('flare_identity.json', 'TűzSelyem_Archívum')
    print(f"Flare neve: {core.identity.get('name')}")
    print(f"Memóriák: {list(core.memories.keys())}")